## Config

FPS = 60
SCREEN_WIDTH = 1500
SCREEN_HEIGHT = 600

# 1 - 10
# 1 is easy
# 10 is hard
DIFFICULTY = 1
# Samuel Abling
# 04/23/2025
# P5HW
# A very simple shooter game where you battle it out with an evil cat.




import pygame
import math
import random
from config import *


## Setup

pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

# Load textures
bg = pygame.image.load("P5HW_AblingSam/bg.png").convert()
cat = pygame.image.load("P5HW_AblingSam/badguy face.png").convert_alpha()
win = pygame.image.load("P5HW_AblingSam/WinState.png").convert_alpha()
win = pygame.transform.scale(win, (200, 200))
lose = pygame.image.load("P5HW_AblingSam/LoseState.png").convert_alpha()
lose = pygame.transform.scale(lose, (200, 200))

# Background setup
bg_width = bg.get_width()
bg_rect = bg.get_rect()
scroll = 0
# Determines how many background tiles are needed to be rendered at any screen width
tiles = math.ceil(SCREEN_WIDTH / bg_width) + 1


## Classes

# Projectile
class projectile(object):

    def __init__(self, x, y, orient):
        
        self.x = x
        self.y = y
        # orient can be L, R, U ,D
        self.orient = orient
        self.vel = 10
        self.size = 5
        self.color = "black"
        self.fireCooldown = 0


    def draw(self):

        pygame.draw.circle(screen, self.color, (self.x, self.y), self.size)


    def travel(self):

        # Left
        if self.orient == 'L':
            self.x -= self.vel
        # Right
        if self.orient == 'R':
            self.x += self.vel
        # Up
        if self.orient == 'U':
            self.x -= self.vel
        # Down
        if self.orient == 'D':
            self.x += self.vel


    def collision(self, shooter, target):

        if isinstance(target, object) and target != shooter:
            if (self.x > target.x and self.x < (target.x + target.width)):
                if (self.y > target.y and self.y < (target.y + target.height)):
                    return True

        


# Player
class playerchar(object):

    def __init__(self):
        
        self.x = SCREEN_WIDTH / 6
        self.y = SCREEN_HEIGHT / 2
        self.size = 40
        self.width = self.size * 2
        self.height = self.size * 2
        self.color = "blue"


        self.hp = 10
        self.playerSpeed = 10


    def draw(self):

        if self.hp > 0:
            pygame.draw.circle(screen, self.color, (self.x, self.y), self.size)

            pygame.draw.circle(screen, "black", (self.x + (self.size), self.y), self.size/4)


    def movement(self):

        # Up
        if keys[pygame.K_w] and self.y > 0:
            self.y -= self.playerSpeed
        # Down
        if keys[pygame.K_s] and self.y <= SCREEN_HEIGHT:
            self.y += self.playerSpeed
        # Right
        if keys[pygame.K_d] and self.x <= SCREEN_WIDTH:
            self.x += self.playerSpeed
        # Left
        if keys[pygame.K_a] and self.x > 0:
            self.x -= self.playerSpeed


# Enemy class
class enemy():

    def __init__(self):

        self.x = SCREEN_WIDTH - (SCREEN_WIDTH / 5)
        self.y = SCREEN_HEIGHT / 2
        self.texture = pygame.transform.scale(cat, (200, 200))
        self.width = self.texture.get_width()
        self.height = self.texture.get_height()
        self.rect = self.texture.get_rect()
        self.hp = 10 + DIFFICULTY

        
        self.moveSpeed = 5
        #random.randint(1, 3)
        
        # If direction = 0, moves up
        # If direction = 1, moves down
        # If direction = 2, stands still
        self.direction = 0
        self.directionTick = 0
        self.directionTickTarget = 40


    def draw(self):

        if self.hp > 0:
            screen.blit(self.texture, (self.x, self.y), self.rect)


    def movement(self):

        ## Changes direction of Y movement, check boundry, then move in that direction

        ## Pick a random direction every directionTickTarget amount of frames
        if self.directionTick > self.directionTickTarget:
            self.directionTick = 0
            self.direction = random.randint(0, 2)

        ## Boundry check
        # Too far up, go down
        if self.y < 0:
            self.direction = 1
            self.directionTick -= 20
        # Too far down, go up
        elif self.y > SCREEN_HEIGHT:
            self.direction = 0
            self.directionTick -= 20

        ## Tick self.directionTick, continue moving in self.direction
        self.directionTick += 1
        # Up
        if self.direction == 0:
            self.y -= self.moveSpeed
        # Down
        elif self.direction == 1:
            self.y += self.moveSpeed
        # Stand
        else:
            pass


## Functions

# Draw all objects, then update display
def drawGame():
    player.draw()
    badGuy.draw()

    for bullet in playerBullets:
        bullet.draw()

    for bullet in enemyBullets:
        bullet.draw()

    pygame.display.update()



# Establish player var
player = playerchar()

# Establish enemy var
badGuy = enemy()

# Projectile lists
playerBullets = []
enemyBullets = []



## RUNTIME
running = True
while running:

    # Event checks
    for event in pygame.event.get():

        # Game quit
        if event.type == pygame.QUIT:
            running = False

        # Player shoots, append a projectile to playerBullets
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            if player.hp > 0:
                playerBullets.append(projectile(player.x, player.y, 'R'))


    # Tick the clock
    clock.tick(FPS)


    # Scroll each background tile
    for i in range(0, tiles):
        screen.blit(bg, (i * bg_width + scroll, 0))
        bg_rect.x = i * bg_width + scroll

        # Seperator line
        #pygame.draw.rect(screen, (255, 0, 0), bg_rect, 1)

    scroll -= 5

    # Reset scroll
    if abs(scroll) > bg_width:
        scroll = 0


    # Grabs keys pressed every game tick
    keys = pygame.key.get_pressed()

    # Player checks
    if player.hp > 0:
        #player.physics()
        player.movement()

    # Player bullet checks
    for bullet in playerBullets:

        # Bullet traveling
        bullet.travel()
        # Remove bullet if hitting edge of screen
        if bullet.x >= SCREEN_WIDTH:
            playerBullets.pop(playerBullets.index(bullet))
        # Bullet collision check collision(shooter, target)
        if bullet.collision(player, badGuy):
            badGuy.hp -= 1
            playerBullets.pop(playerBullets.index(bullet))

    # Enemy checks
    if badGuy.hp > 0:
        badGuy.movement()
        if random.randint(DIFFICULTY, 10) == 10:
            enemyBullets.append(projectile(badGuy.x, badGuy.y, 'L'))


    # Enemy bullet checks
    for bullet in enemyBullets:

        # Bullet traveling
        bullet.travel()
        # Remove bullet if hitting edge of screen
        if bullet.x >= SCREEN_WIDTH:
            enemyBullets.pop(enemyBullets.index(bullet))
        # Bullet collision check collision(shooter, target)
        if bullet.collision(badGuy, player):
            player.hp -= 1
            enemyBullets.pop(enemyBullets.index(bullet))
    
    # End state
    # Win
    if badGuy.hp < 1:
        screen.blit(win, (SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 - 100), win.get_rect())
    # Lose
    elif player.hp < 1:
        screen.blit(lose, (SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 - 100), lose.get_rect())

    # Return check
    if keys[pygame.K_RETURN]:
        player.__init__()
        badGuy.__init__()


    drawGame()

pygame.quit()